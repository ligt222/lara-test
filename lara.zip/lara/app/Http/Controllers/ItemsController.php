<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Items;
use App\Models\Currency;

class ItemsController extends Controller
{

    public function index(): object
    {
        $items = new Items;
        $cur = new Currency;

        $timeBegin = microtime(true);

        $result = $this->modifierResult($items->getItems(), $cur->getItems());

        $timeEnd = microtime(true) - $timeBegin;

        $result['time'] = $timeEnd;

        /*
            Насколько я понял так можно передать в json, а если бы я одним запросом sql сделал то
            в моделе как я понял можно было бы сделать $items = Items::запрос->toJson(); - но я не уверен
         */
        json_encode($result);
        return view('main', compact('result'));

    }

    private function modifierResult($arItems, $arCur): array
    {

        $arResult = [];

        foreach ($arItems as $item) {

            $rubPrice = $item->price * $arCur[$item->currency]->value;

            $arResult['result'][] = [
                'name' => $item->name,
                'category' => $item->category,
                'price' => $item->price,
                'currency' => $item->currency,
                'priceRUB' => number_format($rubPrice, 2, '.', ''),
                'dateCurrency' => $arCur[$item->currency]->date
            ];
        }

        return $arResult;

    }
}
