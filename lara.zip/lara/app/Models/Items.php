<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Items extends Model
{
    use HasFactory;

    protected $table = 'items';

    protected $fillable = [
        'name',
        'category',
        'price',
        'currency'
    ];

    public function getItems(): array
    {

        $arResult = [];

        $arItems = DB::table($this->table)
            ->where('category', '=', '3')
            ->limit(10)
            ->get();

        if ($arItems){

            foreach ($arItems as $item){

                $arResult[] = $item;

            }

        }

        return $arResult;

    }
    /*
     * Сделал одним вариантом только потому что вторым вариантом нужно подольше поразбираться учитывая что я не силен
     *  в запросах. Не так часто приходилось орудовать запросами
     * Второй вариант начал ковырять ниже
     * */
    /*public function getItems(): object
    {

        $obItems = DB::table($this->table)
            ->leftJoin('currency', 'items.currency', '=', 'currency.currency')
            ->select(['items.id', 'items.name', 'items.price', 'currency.currency', 'currency.value', 'currency.date'])
            ->where('items.category', '=', 3)
            ->limit(10)
            ->get();
        return $obItems;

    }*/

}
