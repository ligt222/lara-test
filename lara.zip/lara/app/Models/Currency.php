<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Currency extends Model
{
    use HasFactory;

    protected $table = 'currency';

    protected $fillable = [
        'date',
        'value',
        'currency'
    ];

    public function getItems(): array
    {
        $arResult = [];

        $arItems = DB::table($this->table)
            ->orderBy('date', 'desc')
            ->where('date', '=', '2023.07.01')
            ->get();

        if ($arItems){

            foreach ($arItems as $item){

                $arResult[$item->currency] = $item;

            }

        }

        return $arResult;

    }

}
