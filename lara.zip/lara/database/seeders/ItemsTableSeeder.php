<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ItemsTableSeeder extends Seeder
{

    static string $strRandName = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
    static array $arrValueCurrency = [
        'USD',
        'EUR'
    ];
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('items')->insert([
            'name' => substr(str_shuffle(self::$strRandName), 0, rand(10, 30)),
            'category' => rand(1, 10),
            'price' => number_format((float)rand(1, 10000) / 1.023, 2, '.', ''),
            'currency' => self::$arrValueCurrency[rand(0,1)],
        ]);
    }
}
