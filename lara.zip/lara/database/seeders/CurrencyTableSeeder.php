<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CurrencyTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('currency')->insert([
            'date' => '09.09.2000',
            'currency' => 'USD',
            'value' => number_format((float)rand(10, 100) / 1.023, 2, '.', ''),
        ]);
    }
}
