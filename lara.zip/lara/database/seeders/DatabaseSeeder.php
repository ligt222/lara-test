<?php

namespace Database\Seeders;

use App\Models\Currency;
use App\Models\Items;
use Carbon\CarbonPeriod;
use Illuminate\Database\Seeder;
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */

    public function run()
    {
        Items::factory(400000)->create();

        $dates = CarbonPeriod::create('01.01.2022', '01.07.2023');
        $dates->forEach(function($date) {
            Currency::factory(1)->create([
                'date' => $date->toDateTimeString(),
                'currency' => 'USD',
                'value' => number_format((float)rand(10, 100) / 1.023, 2, '.', ''),
            ]);
            Currency::factory(1)->create([
                'date' => $date->toDateTimeString(),
                'currency' => 'EUR',
                'value' => number_format((float)rand(10, 100) / 1.023, 2, '.', ''),
            ]);
        });
    }
}
