<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ItemsFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    static string $strRandName = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
    static array $arrValueCurrency = [
        'USD',
        'EUR'
    ];
    public function definition()
    {
        return [
            'name' => substr(str_shuffle(self::$strRandName), 0, rand(10, 30)),
            'category' => rand(1, 10),
            'price' => number_format((float)rand(1, 10000) / 1.023, 2, '.', ''),
            'currency' => self::$arrValueCurrency[rand(0,1)]
        ];
    }
}
