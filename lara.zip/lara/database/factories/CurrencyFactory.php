<?php

namespace Database\Factories;

use Carbon\CarbonPeriod;
use Illuminate\Database\Eloquent\Factories\Factory;

class CurrencyFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'date' => $this->faker->dateTime(),
            'currency' => 'USD',
            'value' => number_format((float)rand(10, 100) / 1.023, 2, '.', ''),
        ];
    }
}
